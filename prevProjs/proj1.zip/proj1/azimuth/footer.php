      <div class="footer">
	 <div class="department">
          <p>
            Computer Science and Electrical Engineering<br />
	 1000 Hilltop Circle, Baltimore, MD 21250<br />
          </p>
	 </div>
	 <div class="contact">
          <p>
            <a href="<?php echo $ROOT; ?>privacy.php">[ Privacy Policy ]</a><br />
          </p>
	 </div>
      </div>
    </div>
  </body>
</html>